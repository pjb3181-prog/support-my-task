Story Director v1.2.8 (AI autonomous editor mode)

설치 및 역할
- 이 ZIP의 Story_Director_v1.2.8.ts 파일만 압축 해제하여 설치하세요.
- RisuBard 설정 -> 플러그인 -> + -> .ts 파일을 선택하세요.
- 기존 story_director 플러그인이 있으면 새 복제본 추가가 아닌 같은 ID로 교체하세요.
- 기존 //@name, 업데이트 URL, 저장 키는 유지했습니다.

기본 작동
- AI 자율 전개: 입력하지 않아도 기존 채팅/인물 설정을 기반으로 AI가 다음 내용을 결정하도록 브리프 생성
- AI에게 맡겨 바로 이어가기: 사용자 확인을 거쳐 실제 채팅으로 자동 전송하고 메인 AI가 집필
- 상담·판정·세부 지시는 기존처럼 선택적으로 사용
- 자동 무제한 연속 생성 기능은 아닙니다. 실제 AI 모델 동작과 모바일 설치는 별도 확인이 필요합니다.

보관 주의사항
- 캐릭터/채팅/로어북/에셋/개인 저장값/API 키는 이 ZIP에 포함하지 않습니다.
- 설치 전에 RisuBard 데이터 백업을 권장합니다.
- 이미 1.2.7이 설치되어 있다면 내부 자동업데이트 경로가 1.2.8 최신본을 가리킵니다. 다만 갱신은 RisuBard에서 확인 후 적용하는 구조입니다.

정본: https://github.com/pjb3181-prog/support-my-task/blob/main/risubard-updates/story_director.ts
