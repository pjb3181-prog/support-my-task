RisuBard PC -> Android plugin bundle (2026-11-16)

This ZIP contains 7 full GitHub-main plugin sources, not stubs.
PC-installed versions cannot be independently verified from GitHub.
Install only the plugins actually enabled on your PC.

Install on Android:
1. Unzip this archive on your phone.
2. Open RisuBard > Settings > Plugins > Add/Import.
3. Choose a .js or .ts file ONE AT A TIME.
4. A plugin with the same internal //@name must be updated, not duplicated.
5. Compare IDs, versions, enabled flags, and any plugin settings with PC.

Update URLs are preserved within every source file. RisuBard can check for
updates, but applying an update normally requires a user confirmation.

Plugin code does NOT include or sync pluginStorage, character/chats,
Lorebooks, modules, image assets, model/API settings, or secrets.
Character Mixer's PC Python localhost bridge cannot run as-is on Android.
Asset Link Bridge requires its underlying image modules/assets.

Files:
- 01_Story_Runner_v0.95.10.ts : story_runner (0.95.10)
- 02_Mutation_State_Router_v0.79.6.ts : mutation_state_router_v2 (0.79.6)
- 03_Bard_Editor_Lab_v0.3.11.js : bard_editor_lab (0.3.11)
- 04_Story_Director_v1.2.7.ts : story_director (1.2.7)
- 05_World_Editor_Lab_v0.1.2.js : world_editor_lab (0.1.2)
- 06_Character_Mixer_v0.10.5.js : character_mixer (0.10.5)
- 07_Asset_Link_Bridge_v0.8.1.js : risubard_asset_link_bridge (0.8.1)

Source: https://github.com/pjb3181-prog/support-my-task
